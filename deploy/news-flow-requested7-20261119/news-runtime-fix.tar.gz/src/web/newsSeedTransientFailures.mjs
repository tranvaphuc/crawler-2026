const supportedStatuses=new Set([502,503,504]);

// Retry only explicitly configured publishers, on the next seed cycle.
// Article failures and permanent/access failures retain their review requirement.
export function seedTransientFailurePolicies(sources){
  const policies=new Map();
  for(const source of sources){
    const statuses=source.config?.discovery?.retryTransientHttpStatuses;
    if(!Array.isArray(statuses))continue;
    const reasons=new Set(statuses.filter(status=>supportedStatuses.has(status)).map(status=>'http_'+status));
    if(reasons.size)policies.set(source.domain,reasons);
  }
  return policies;
}

export function isConfiguredTransientSeedFailure(policies,site,reason){
  return policies?.get(site)?.has(reason)===true;
}
